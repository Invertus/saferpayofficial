<?php
/**
 *NOTICE OF LICENSE
 *
 *This source file is subject to the Open Software License (OSL 3.0)
 *that is bundled with this package in the file LICENSE.txt.
 *It is also available through the world-wide-web at this URL:
 *http://opensource.org/licenses/osl-3.0.php
 *If you did not receive a copy of the license and are unable to
 *obtain it through the world-wide-web, please send an email
 *to license@prestashop.com so we can send you a copy immediately.
 *
 *DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 *versions in the future. If you wish to customize PrestaShop for your
 *needs please refer to http://www.prestashop.com for more information.
 *
 *@author INVERTUS UAB www.invertus.eu  <support@invertus.eu>
 *@copyright SIX Payment Services
 *@license   SIX Payment Services
 */


return [
  'parameters' => [
    'database_host' => 'mysql',
    'database_port' => '',
    'database_name' => 'prestashop',
    'database_user' => 'root',
    'database_password' => 'prestashop',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => null,
    'mailer_password' => null,
    'secret' => '5me4mdumTjYo4jPpNtQSuRN1MyD9wSSze7VuLg4s2ktMUxkXHihrLXZV1NaHuzhU',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2020-12-23',
    'locale' => 'en-US',
    'use_debug_toolbar' => true,
    'cookie_key' => '6NiLzzVp8Z9LiOtHgBNScv929I2K8a2A8jNppJVz1t5WjnnRGPbXVXKS',
    'cookie_iv' => 'TtPM0O7S',
    'new_cookie_key' => 'def000001b90465d16f2aa760abe76e1a88fb80071075978db96754d16fd83cef2c9d8d1218a6dba2f28cee48e527700e85ddf87731652776449d60f9f4e1cceb90198b2',
  ],
];
